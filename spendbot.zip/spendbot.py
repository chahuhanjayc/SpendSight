"""
SpendBot — Rule-based conversational assistant for SpendSight.

No external AI/LLM APIs.  Uses only: datetime, re, and standard library.
"""

import re
from datetime import date, datetime
from difflib import get_close_matches, SequenceMatcher

# ---------------------------------------------------------------------------
# Default subcategory corpus (mirrors DEFAULT_CATEGORIES in app.py)
# ---------------------------------------------------------------------------
DEFAULT_CATEGORIES = {
    "Groceries":     ["Milk", "Dal", "Rice", "Sugar", "Atta", "Oil", "Soap",
                      "Shampoo", "Vegetables", "Fruits", "Eggs", "Pulses",
                      "Ghee", "Butter", "Tea"],
    "Fast Food":     ["McDonald's", "Wada Pav", "Pani Puri", "Samosa", "Pizza",
                      "Chai", "Biryani", "Thali", "Dosa", "Idli", "Burger", "Noodles"],
    "Fuel":          ["Petrol", "Diesel", "CNG"],
    "Utilities":     ["Electricity", "Water", "Gas Cylinder", "Internet",
                      "Mobile Recharge", "DTH"],
    "Entertainment": ["Netflix", "Amazon Prime", "Hotstar", "Movies", "Games",
                      "Events", "Spotify"],
    "Health":        ["Medicine", "Doctor", "Gym", "Supplements", "Lab Test", "Dental"],
    "Transport":     ["Ola/Uber", "Local Train", "Bus", "Auto", "Metro", "Parking"],
    "Shopping":      ["Clothing", "Electronics", "Household", "Personal Care",
                      "Accessories", "Books"],
    "EMI / Finance": ["Card EMI", "Loan EMI", "Insurance Premium", "SIP", "Rent"],
    "Other":         ["Miscellaneous", "Gifts", "Donations", "Fees"],
}

# ---------------------------------------------------------------------------
# Month-name → number mapping (full + 3-letter abbreviations)
# ---------------------------------------------------------------------------
MONTH_NAMES = {
    "january": 1,  "jan": 1,
    "february": 2, "feb": 2,
    "march": 3,    "mar": 3,
    "april": 4,    "apr": 4,
    "may": 5,
    "june": 6,     "jun": 6,
    "july": 7,     "jul": 7,
    "august": 8,   "aug": 8,
    "september": 9,"sep": 9,  "sept": 9,
    "october": 10, "oct": 10,
    "november": 11,"nov": 11,
    "december": 12,"dec": 12,
}

MONTH_DISPLAY = {
    1: "January", 2: "February", 3: "March", 4: "April",
    5: "May", 6: "June", 7: "July", 8: "August",
    9: "September", 10: "October", 11: "November", 12: "December",
}

# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------
# "March 2026", "Jan 2025", etc.
_RE_MONTH_YEAR = re.compile(
    r"\b(january|february|march|april|may|june|july|august|september|october|november|december"
    r"|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)"
    r"(?:\s+(\d{4}))?\b",
    re.IGNORECASE,
)

_RE_THIS_MONTH  = re.compile(r"\bthis\s+month\b", re.IGNORECASE)
_RE_LAST_MONTH  = re.compile(r"\blast\s+month\b", re.IGNORECASE)
_RE_YTD         = re.compile(r"\b(year\s+to\s+date|ytd)\b", re.IGNORECASE)
_RE_NEXT_MONTH  = re.compile(r"\bnext\s+month\b", re.IGNORECASE)

# Intent: total / overall
_RE_TOTAL_INTENT = re.compile(
    r"\b(total|overall|all|everything|sum|how much (did i |have i )?spend(t)?|"
    r"expense[s]?|spending)\b",
    re.IGNORECASE,
)

# Gibberish guard: if the message has fewer than 2 word-like tokens, treat as gibberish
_RE_WORD = re.compile(r"[a-zA-Z]{2,}")

# ---------------------------------------------------------------------------
# Fuzzy / normalised matching helpers
# ---------------------------------------------------------------------------

# Simple suffix rules for plural → singular (applied to normalised lowercase)
_PLURAL_RULES = [
    (r"groceries$", "grocery"), (r"berries$", "berry"),
    (r"ies$",       "y"),       (r"ves$",     "f"),
    (r"ses$",       "s"),       (r"s$",       ""),
]

# Alias map: normalised user input → normalised canonical key
_COMMON_ALIASES: dict[str, str] = {
    "panipuri":      "pani puri",
    "wadapav":       "wada pav",
    "fastfood":      "fast food",
    "mcdonalds":     "mcdonald's",
    "mobilerecharge":"mobile recharge",
    "gascylinder":   "gas cylinder",
    "labtest":       "lab test",
    "amazomprime":   "amazon prime",
    "amazone":       "amazon prime",
    "olauber":       "ola/uber",
    "cardemi":       "card EMI",
    "loanemi":       "loan EMI",
}

# Threshold constants
_AUTO_MATCH_THRESHOLD  = 0.82   # ≥ this → auto-match with a correction note
_SUGGEST_THRESHOLD     = 0.70   # ≥ this (but < AUTO) → ask "Did you mean?"


def _normalize(text: str) -> str:
    """Lowercase; remove spaces, hyphens, slashes."""
    return re.sub(r"[\s\-/]+", "", text.lower())


def _singularize(word: str) -> str:
    """Best-effort plural → singular on a *normalised* (space-free) lowercase word."""
    for pattern, repl in _PLURAL_RULES:
        if re.search(pattern, word):
            candidate = re.sub(pattern, repl, word)
            if len(candidate) >= 2:          # don't collapse to empty
                return candidate
    return word


def detect_item_with_suggestions(
    user_message: str,
    expenses: list,
    default_categories: dict,
) -> tuple:
    """
    Fuzzy / normalised item detection — no external APIs.

    Priority order
    --------------
    1. Exact match (case-insensitive)
    2. Normalised match  (strip spaces/hyphens + alias map)
    3. Singular-form match
    4. Fuzzy via difflib  (SequenceMatcher score ≥ 0.85 → auto; 0.70–0.85 → suggest)
    5. Substring match

    Parameters
    ----------
    user_message       : raw user text
    expenses           : list of expense dicts (to pick up custom subcategories)
    default_categories : {category: [subcategory, …]}

    Returns
    -------
    matched_item    : str | None          canonical name, or None
    match_type      : str                 'exact'|'normalized'|'fuzzy'|'substring'|'suggestion'|'none'
    confidence      : float               0.0–1.0
    suggestion_text : str                 human-readable note / question
    alternatives    : list[str]           up to 8 candidate names for "none" / "suggestion" cases
    """
    # Build combined term dict: lower → canonical
    all_terms: dict[str, str] = {}
    for cat, subs in default_categories.items():
        all_terms[cat.lower()] = cat
        for sub in subs:
            all_terms[sub.lower()] = sub
    for exp in expenses:
        for key in ("category", "subcategory"):
            val = (exp.get(key) or "").strip()
            if val:
                all_terms[val.lower()] = val

    # Extract candidate token (word/phrase after "on / about / spent on")
    m = re.search(
        r"\b(?:on|about|spent\s+on)\s+([a-z][a-z\s]{0,25}?)"
        r"(?:\s+(?:this|last|in|for|january|february|march|april|may|june|july"
        r"|august|september|october|november|december|\d{4})|[?,.!]|$)",
        user_message.lower(),
    )
    token = m.group(1).strip() if m else user_message.lower().strip()
    if not token:
        alts = sorted({v for v in all_terms.values()}, key=str.lower)[:8]
        return None, "none", 0.0, "", alts

    all_canonicals = sorted({v for v in all_terms.values()}, key=str.lower)

    # ── 1. Exact match ────────────────────────────────────────────────────
    if token in all_terms:
        return all_terms[token], "exact", 1.0, "", []

    # ── 2. Normalised match + alias ───────────────────────────────────────
    norm_token = _normalize(token)
    resolved   = _COMMON_ALIASES.get(norm_token, norm_token)
    norm_map: dict[str, str] = {_normalize(k): v for k, v in all_terms.items()}

    for candidate in (resolved, norm_token):
        if candidate in norm_map:
            return norm_map[candidate], "normalized", 0.95, f"(you typed '{token}')", []

    # ── 3. Singular-form match ────────────────────────────────────────────
    singular = _singularize(norm_token)
    for nk, canon in norm_map.items():
        if _singularize(nk) == singular or nk == singular:
            return canon, "normalized", 0.92, f"(you typed '{token}')", []

    # ── 4. Fuzzy via difflib ──────────────────────────────────────────────
    norm_keys = list(norm_map.keys())
    close = get_close_matches(norm_token, norm_keys, n=3, cutoff=_SUGGEST_THRESHOLD)
    if close:
        best  = close[0]
        score = SequenceMatcher(None, norm_token, best).ratio()
        canon = norm_map[best]
        if score >= _AUTO_MATCH_THRESHOLD:
            return canon, "fuzzy", score, f"(you typed '{token}')", []
        else:
            alts = [norm_map[c] for c in close[1:3]]
            return (canon, "suggestion", score,
                    f"Did you mean '{canon}'? (from '{token}')", alts)

    # ── 5. Substring match ────────────────────────────────────────────────
    for lower_key, canon in all_terms.items():
        if token in lower_key or (len(token) >= 3 and lower_key.startswith(token)):
            return canon, "substring", 0.75, f"(matched '{canon}' from '{token}')", []

    # ── No match ──────────────────────────────────────────────────────────
    return None, "none", 0.0, f"I don't recognize '{token}'.", all_canonicals[:8]


# ---------------------------------------------------------------------------
# SpendBot
# ---------------------------------------------------------------------------

class SpendBot:
    """
    Rule-based spending assistant.

    Parameters
    ----------
    expenses : list[dict]
        List of expense records with keys: amount, category, subcategory, date
    custom_categories : dict, optional
        Extra {category: [subcategory, …]} from user data, merged with defaults
    currency_symbol : str
        Symbol to use in replies (default "₹")
    """

    def __init__(self, expenses: list, custom_categories: dict = None,
                 currency_symbol: str = "₹"):
        self.expenses        = expenses
        self.currency_symbol = currency_symbol

        # Build merged category map and flat subcategory list
        self._categories: dict[str, list[str]] = {}
        for cat, subs in DEFAULT_CATEGORIES.items():
            self._categories[cat] = list(subs)
        for cat, subs in (custom_categories or {}).items():
            if cat in self._categories:
                existing = {s.lower() for s in self._categories[cat]}
                self._categories[cat] += [s for s in subs if s.lower() not in existing]
            else:
                self._categories[cat] = list(subs)

        # Flat list of all subcategories (lower-cased) → canonical form
        self._sub_to_canonical: dict[str, str] = {}
        self._cat_to_canonical: dict[str, str] = {}
        for cat, subs in self._categories.items():
            self._cat_to_canonical[cat.lower()] = cat
            for sub in subs:
                self._sub_to_canonical[sub.lower()] = sub

    # ------------------------------------------------------------------
    # Public entry-point
    # ------------------------------------------------------------------

    def reply(self, message: str) -> dict:
        """
        Process a user message and return a response dict:

        {
            "reply":     str,
            "total":     float | None,
            "item":      str | None,
            "timeframe": str | None
        }
        """
        msg = message.strip()

        # Guard: empty or gibberish
        # Allow single-word messages if they're a known item or a month name
        words = _RE_WORD.findall(msg)
        if not msg or (
            len(words) < 2
            and not _RE_MONTH_YEAR.search(msg)
            and self._detect_item(msg) is None
        ):
            return self._clarify(
                "Sorry, I didn't understand. Try asking like "
                "'How much on milk this month?'"
            )

        # 1. Detect timeframe
        timeframe_result = self._detect_timeframe(msg)
        if timeframe_result is None:
            # "next month" or invalid future timeframe
            return self._clarify(
                "Sorry, I can only look at current or past months. "
                "Try 'this month', 'last month', or a specific month like 'March 2026'."
            )
        start_date, end_date, tf_label, tf_defaulted = timeframe_result

        # 2. Detect item (subcategory / category)
        item_result = self._detect_item(msg)
        # item_result: None = not found / ambiguous, or (canonical_name, is_exact)

        # 3. Detect total intent
        has_total_intent = bool(_RE_TOTAL_INTENT.search(msg))

        # 4. Route to handler
        # Priority: if specific item detected → item query
        #           else if total intent → total query
        #           else → ask for clarification
        if item_result is not None:
            item_name, _is_exact = item_result
            return self._item_query(item_name, start_date, end_date, tf_label, tf_defaulted)

        # Exact word-boundary match failed — try fuzzy / normalised matching.
        # This handles typos ("vegitable"), spacing ("panipuri"), plurals ("vegetables"),
        # and partial matches ("veg") before giving up or falling back to a total query.
        fuzzy_reply = self._detect_item_fuzzy(
            msg, start_date, end_date, tf_label, tf_defaulted
        )
        if fuzzy_reply is not None:
            return fuzzy_reply

        # Fuzzy also found nothing.  If the user typed something that *looks* like
        # an item keyword but we still can't recognise it, say so explicitly rather
        # than silently returning a total.
        unknown = self._detect_unknown_item(msg)
        if unknown:
            available = self._available_items()
            return self._clarify(
                f"I don't recognize '{unknown}'. "
                f"Try: {', '.join(available[:8])}"
                + (" …" if len(available) > 8 else "")
            )

        # Total query: explicit total intent OR user explicitly named a timeframe
        # (tf_defaulted=False means they said "March", "last month", etc.)
        if has_total_intent or not tf_defaulted:
            return self._total_query(start_date, end_date, tf_label, tf_defaulted)

        return self._clarify(
            "Sorry, I didn't quite catch that. "
            "Try 'How much on milk this month?' or 'Total expense for March'."
        )

    # ------------------------------------------------------------------
    # Timeframe detection
    # ------------------------------------------------------------------

    def _detect_timeframe(self, msg: str):
        """
        Returns (start_date, end_date, label, defaulted) or None for invalid.

        defaulted=True when we silently fell back to this month.
        """
        today = date.today()

        # "next month" → invalid
        if _RE_NEXT_MONTH.search(msg):
            return None

        # "this month"
        if _RE_THIS_MONTH.search(msg):
            return *self._month_range(today.year, today.month), \
                   f"{MONTH_DISPLAY[today.month]} {today.year}", False

        # "last month"
        if _RE_LAST_MONTH.search(msg):
            m, y = today.month - 1, today.year
            if m == 0:
                m, y = 12, y - 1
            return *self._month_range(y, m), f"{MONTH_DISPLAY[m]} {y}", False

        # Year-to-date
        if _RE_YTD.search(msg):
            start = date(today.year, 1, 1)
            label = f"Jan–{MONTH_DISPLAY[today.month]} {today.year}"
            return start, today, label, False

        # Named month (+ optional year)
        m = _RE_MONTH_YEAR.search(msg)
        if m:
            month_num = MONTH_NAMES[m.group(1).lower()]
            year      = int(m.group(2)) if m.group(2) else today.year

            # Reject future months
            target = date(year, month_num, 1)
            if target > today.replace(day=1):
                return None

            label = f"{MONTH_DISPLAY[month_num]} {year}"
            return *self._month_range(year, month_num), label, False

        # Default → this month
        return (*self._month_range(today.year, today.month),
                f"{MONTH_DISPLAY[today.month]} {today.year}", True)

    @staticmethod
    def _month_range(year: int, month: int):
        from calendar import monthrange as _mr
        last_day = _mr(year, month)[1]
        return date(year, month, 1), date(year, month, last_day)

    # ------------------------------------------------------------------
    # Item detection
    # ------------------------------------------------------------------

    def _detect_item(self, msg: str):
        """
        Scan message for known subcategories / categories.
        Returns (canonical_name, is_category_level) or None.

        Strategy:
        - Longest-match wins (avoids "burger" matching inside "burger king").
        - Case-insensitive.
        - Matches both subcategories and top-level categories.
        """
        msg_lower = msg.lower()

        # Build a sorted list (longest first) so multi-word items take precedence
        candidates = []
        for sub_lower, canonical in self._sub_to_canonical.items():
            candidates.append((sub_lower, canonical, False))
        for cat_lower, canonical in self._cat_to_canonical.items():
            candidates.append((cat_lower, canonical, True))

        candidates.sort(key=lambda x: len(x[0]), reverse=True)

        for term, canonical, is_cat in candidates:
            # Word-boundary aware match: term must appear as a whole word / phrase
            pattern = r"\b" + re.escape(term) + r"\b"
            if re.search(pattern, msg_lower):
                return canonical, is_cat

        return None

    def _detect_item_fuzzy(
        self,
        msg: str,
        start: date,
        end: date,
        tf_label: str,
        tf_defaulted: bool,
    ) -> dict | None:
        """
        Call the module-level detect_item_with_suggestions() and convert the
        result into a full reply dict, or return None if nothing was found.

        match_type routing
        ------------------
        exact / normalized / fuzzy / substring  → auto-match with an optional note
        suggestion (score 0.70–0.85)            → ask "Did you mean …?" and return
                                                  extra fields so app.py can store
                                                  the pending suggestion in session
        none                                    → return None (caller decides)
        """
        matched, match_type, confidence, suggestion_text, alts = \
            detect_item_with_suggestions(msg, self.expenses, self._categories)

        if matched is None or match_type == "none":
            return None

        if match_type == "suggestion":
            # Medium confidence — ask the user to confirm before running the query
            r = self._clarify(
                f"Did you mean '{matched}'? "
                f"Reply 'yes' to confirm, or retype the item name."
            )
            # Extra fields consumed by /api/chat to persist the pending state
            r["match_type"]    = "suggestion"
            r["suggested_item"] = matched
            r["_start"]        = start.isoformat()
            r["_end"]          = end.isoformat()
            r["_tf_label"]     = tf_label
            r["_tf_defaulted"] = tf_defaulted
            return r

        # Auto-match: run the normal item query, prepend a correction note if needed
        r    = self._item_query(matched, start, end, tf_label, tf_defaulted)
        note = suggestion_text   # e.g. "(you typed 'vegitable')"
        if note:
            r["reply"] = f"Showing results for '{matched}' {note}. {r['reply']}"
        r["match_type"] = match_type
        return r

    def _detect_unknown_item(self, msg: str) -> str | None:
        """
        Look for a noun-like word after common question prepositions
        ('on', 'for', 'about', 'spent on') that isn't in our vocabulary.
        Returns the unknown token, or None.
        """
        # e.g. "what about coffee", "spent on coffee", "how much on coffee"
        pattern = (
            r"\b(?:on|about|spent on)\s+([a-z][a-z\s]{1,20}?)"
            r"(?:\s+(?:this|last|in|for|january|february|march|april|may|june|july"
            r"|august|september|october|november|december|\d{4})|[?,.]|$)"
        )
        m = re.search(pattern, msg.lower())
        if m:
            candidate = m.group(1).strip()
            # Exclude pure timeframe words and month names
            timeframe_words = {
                "month", "year", "date", "today", "week", "yesterday",
            } | set(MONTH_NAMES.keys())
            if candidate not in timeframe_words:
                return candidate
        return None

    def _available_items(self) -> list[str]:
        """Flat sorted list of all known subcategory names."""
        seen = set()
        items = []
        for subs in self._categories.values():
            for s in subs:
                sl = s.lower()
                if sl not in seen:
                    seen.add(sl)
                    items.append(s)
        return sorted(items, key=str.lower)

    # ------------------------------------------------------------------
    # Query handlers
    # ------------------------------------------------------------------

    def _item_query(self, item_name: str, start: date, end: date,
                    tf_label: str, defaulted: bool) -> dict:
        """Return spending on a specific item within the date range."""
        matching = self._filter_expenses(item_name, start, end)
        total    = sum(e["amount"] for e in matching)

        suffix = " (defaulting to this month)" if defaulted else ""

        if total == 0:
            reply = (
                f"I couldn't find any expenses for {item_name} in {tf_label}."
            )
            return {"reply": reply, "total": 0.0,
                    "item": item_name.lower(), "timeframe": tf_label}

        reply = (
            f"You spent {self._fmt(total)} on {item_name} "
            f"in {tf_label}{suffix}."
        )
        return {"reply": reply, "total": round(total, 2),
                "item": item_name.lower(), "timeframe": tf_label}

    def _total_query(self, start: date, end: date,
                     tf_label: str, defaulted: bool) -> dict:
        """Return total of all expenses within the date range."""
        matching = [
            e for e in self.expenses
            if start <= self._parse_date(e.get("date", "")) <= end
        ]
        total = sum(e["amount"] for e in matching)

        suffix = " (defaulting to this month)" if defaulted else ""

        if total == 0:
            reply = f"No expenses recorded for {tf_label}{suffix}."
            return {"reply": reply, "total": 0.0,
                    "item": None, "timeframe": tf_label}

        reply = (
            f"Your total expenses for {tf_label} were "
            f"{self._fmt(total)}{suffix}."
        )
        return {"reply": reply, "total": round(total, 2),
                "item": None, "timeframe": tf_label}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _filter_expenses(self, item_name: str, start: date, end: date) -> list:
        """
        Return expenses whose subcategory OR category contains item_name
        (case-insensitive, partial match for multi-word items).
        """
        item_lower = item_name.lower()
        results    = []
        for e in self.expenses:
            sub = (e.get("subcategory") or "").lower()
            cat = (e.get("category")    or "").lower()
            if item_lower in sub or item_lower in cat or sub in item_lower or cat in item_lower:
                try:
                    d = self._parse_date(e.get("date", ""))
                    if start <= d <= end:
                        results.append(e)
                except ValueError:
                    pass
        return results

    @staticmethod
    def _parse_date(date_str: str) -> date:
        """Parse ISO date string → date object. Raises ValueError on failure."""
        if not date_str:
            raise ValueError("empty date")
        return datetime.strptime(date_str, "%Y-%m-%d").date()

    def _fmt(self, amount: float) -> str:
        """Indian lakh-style currency formatting using the instance symbol."""
        symbol = self.currency_symbol
        v = int(round(amount))
        if v < 0:
            return f"-{self._fmt(-amount)}"
        s = str(v)
        if len(s) <= 3:
            return f"{symbol}{s}"
        last3 = s[-3:]
        rest  = s[:-3]
        groups: list[str] = []
        while len(rest) > 2:
            groups.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            groups.insert(0, rest)
        return f"{symbol}{','.join(groups)},{last3}"

    @staticmethod
    def _clarify(msg: str) -> dict:
        return {"reply": msg, "total": None, "item": None, "timeframe": None}
