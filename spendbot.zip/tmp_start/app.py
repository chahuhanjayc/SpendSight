"""
SpendSight - Personal Finance Tracker
Local Flask web app — data stored in expenses.json
Run: python app.py  then open http://localhost:5000
"""

from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
import json
import os
from datetime import date, datetime, timedelta
from calendar import monthrange
import uuid
from collections import defaultdict
import webbrowser
import threading
import secrets
import urllib.parse
import urllib.request
import csv
import io

app = Flask(__name__)
app.secret_key = "spendsight-local-2026"

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "expenses.json")

# ── Default data ──────────────────────────────────────────────────────────────

DEFAULT_CATEGORIES = {
    "Groceries":    ["Milk", "Dal", "Rice", "Sugar", "Atta", "Oil", "Soap",
                     "Shampoo", "Vegetables", "Fruits", "Eggs", "Pulses", "Ghee", "Butter", "Tea"],
    "Fast Food":    ["McDonald's", "Wada Pav", "Pani Puri", "Samosa", "Pizza",
                     "Chai", "Biryani", "Thali", "Dosa", "Idli", "Burger", "Noodles"],
    "Fuel":         ["Petrol", "Diesel", "CNG"],
    "Utilities":    ["Electricity", "Water", "Gas Cylinder", "Internet", "Mobile Recharge", "DTH"],
    "Entertainment":["Netflix", "Amazon Prime", "Hotstar", "Movies", "Games", "Events", "Spotify"],
    "Health":       ["Medicine", "Doctor", "Gym", "Supplements", "Lab Test", "Dental"],
    "Transport":    ["Ola/Uber", "Local Train", "Bus", "Auto", "Metro", "Parking"],
    "Shopping":     ["Clothing", "Electronics", "Household", "Personal Care", "Accessories", "Books"],
    "EMI / Finance":["Card EMI", "Loan EMI", "Insurance Premium", "SIP", "Rent"],
    "Other":        ["Miscellaneous", "Gifts", "Donations", "Fees"],
}

CATEGORY_COLORS = {
    "Groceries":     "#0E9F6E",
    "Fast Food":     "#E3A008",
    "Fuel":          "#1A56DB",
    "Utilities":     "#6B7280",
    "Entertainment": "#7E3AF2",
    "Health":        "#F05252",
    "Transport":     "#FF8C00",
    "Shopping":      "#0694A2",
    "EMI / Finance": "#C81E1E",
    "Other":         "#9CA3AF",
}

DEFAULT_PAYMENT_METHODS = ["Cash", "Card 1", "Card 2", "Card 3"]

CURRENCIES = [
    {"code": "INR", "symbol": "₹",   "name": "Indian Rupee"},
    {"code": "USD", "symbol": "$",    "name": "US Dollar"},
    {"code": "EUR", "symbol": "€",    "name": "Euro"},
    {"code": "GBP", "symbol": "£",    "name": "British Pound"},
    {"code": "AED", "symbol": "د.إ",  "name": "UAE Dirham"},
    {"code": "SGD", "symbol": "S$",   "name": "Singapore Dollar"},
    {"code": "CAD", "symbol": "CA$",  "name": "Canadian Dollar"},
    {"code": "AUD", "symbol": "A$",   "name": "Australian Dollar"},
    {"code": "JPY", "symbol": "¥",    "name": "Japanese Yen"},
    {"code": "MYR", "symbol": "RM",   "name": "Malaysian Ringgit"},
    {"code": "BRL", "symbol": "R$",   "name": "Brazilian Real"},
    {"code": "NGN", "symbol": "₦",    "name": "Nigerian Naira"},
    {"code": "ZAR", "symbol": "R",    "name": "South African Rand"},
    {"code": "PKR", "symbol": "Rs",   "name": "Pakistani Rupee"},
    {"code": "BDT", "symbol": "৳",    "name": "Bangladeshi Taka"},
]

# ── Data helpers ──────────────────────────────────────────────────────────────

def load_data():
    if not os.path.exists(DATA_FILE):
        data = {
            "expenses": [],
            "templates": [],
            "custom_categories": {},
            "payment_methods": DEFAULT_PAYMENT_METHODS,
            "billing_start_day": 1,
            "income": {"monthly_salary": 0, "salary_history": []},
            "extra_income": [],
            "fixed_expenses": [],
        }
        save_data(data)
        return data
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        d = json.load(f)
    # back-compat defaults
    d.setdefault("billing_start_day", 1)
    d.setdefault("income", {"monthly_salary": 0, "salary_history": []})
    d.setdefault("extra_income", [])
    d.setdefault("fixed_expenses", [])
    d.setdefault("currency_code", "INR")

    # ── Migrate old flat salary to history format ────────────────────────────
    income = d["income"]
    if "salary_history" not in income:
        sal = float(income.get("monthly_salary", 0))
        if sal > 0:
            effective = income.get("salary_updated", date.today().isoformat())
            income["salary_history"] = [{
                "amount":         round(sal, 2),
                "effective_from": effective,
                "added_on":       effective,
            }]
        else:
            income["salary_history"] = []
    return d

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=str)

def get_salary_for_date(income_data, target_date):
    """Return the monthly salary effective on target_date from salary_history.

    Falls back to the flat monthly_salary field for backward compatibility.
    """
    history = income_data.get("salary_history", [])
    if not history:
        return float(income_data.get("monthly_salary", 0))
    target_str = target_date.isoformat() if hasattr(target_date, "isoformat") else str(target_date)
    applicable = [h for h in history if h["effective_from"] <= target_str]
    if not applicable:
        return 0.0
    # Most recent entry whose effective_from <= target_date
    return float(sorted(applicable, key=lambda h: h["effective_from"])[-1]["amount"])


def get_all_categories(data):
    cats = {k: list(v) for k, v in DEFAULT_CATEGORIES.items()}
    for cat, subs in data.get("custom_categories", {}).items():
        if cat in cats:
            for s in subs:
                if s not in cats[cat]:
                    cats[cat].append(s)
        else:
            cats[cat] = subs
    return cats

def today_str():
    return date.today().isoformat()

def get_billing_period(billing_start_day=1):
    """Return (start_date, end_date) for the current billing month.

    Example: billing_start_day=5, today=Mar 19
      → start = Mar 5, end = Apr 4
    Example: billing_start_day=25, today=Mar 19
      → start = Feb 25, end = Mar 24
    """
    today = date.today()
    day = min(billing_start_day, 28)  # cap at 28 to handle all months

    if today.day >= day:
        start = today.replace(day=day)
        # end = day-1 of next month
        if start.month == 12:
            end = date(start.year + 1, 1, day) - timedelta(days=1)
        else:
            end = date(start.year, start.month + 1, day) - timedelta(days=1)
    else:
        # start = day of previous month
        if today.month == 1:
            start = date(today.year - 1, 12, day)
        else:
            start = date(today.year, today.month - 1, day)
        end = today.replace(day=day) - timedelta(days=1)

    return start, end

def billing_period_label(billing_start_day=1):
    """Human-readable label like 'Mar 5 – Apr 4'."""
    start, end = get_billing_period(billing_start_day)
    if start.month == end.month:
        return f"{start.strftime('%b')} {start.day} – {end.day}"
    return f"{start.strftime('%b')} {start.day} – {end.strftime('%b')} {end.day}"

def get_n_billing_months_ago(n, billing_start_day):
    """Return (start_date, end_date) spanning N billing months back from the
    current billing period end.

    Example: billing_start_day=21, today=Mar 19 (billing period = Feb 21–Mar 20)
      n=3 → Dec 21–Mar 20   (3 billing months: Dec 21–Jan 20, Jan 21–Feb 20, Feb 21–Mar 20)
      n=6 → Sep 21–Mar 20
      n=12 → Mar 21–Mar 20  (full year of billing months)
    """
    curr_start, curr_end = get_billing_period(billing_start_day)
    day = min(billing_start_day, 28)

    # Go back N months from curr_start
    month = curr_start.month - n
    year  = curr_start.year
    while month <= 0:
        month += 12
        year  -= 1

    max_day = monthrange(year, month)[1]
    start   = date(year, month, min(day, max_day))
    return start, curr_end


# ── EMI / Income helpers ───────────────────────────────────────────────────────

def get_emi_status(emi, ref_date=None):
    """Return status dict for an EMI or Fixed Expense.

    Args:
        emi: dict with type, amount, etc.
        ref_date: date to evaluate against (defaults to today)

    Returns dict with keys: paid, remaining, total, is_active,
        end_year, end_month, progress_pct, amount_due (0 if done)
    """
    ref = ref_date or date.today()
    emi_type = emi.get("type", "emi")
    sy, sm = int(emi["start_year"]), int(emi["start_month"])

    if emi_type == "emi":
        total = int(emi.get("total_months", 0))
        # Months elapsed since start month (inclusive)
        elapsed = (ref.year - sy) * 12 + (ref.month - sm) + 1
        paid    = min(max(elapsed, 0), total)
        remaining = total - paid
        is_active = paid < total

        # Compute end month (0-indexed offset from start)
        offset = total - 1
        ey = sy + (sm - 1 + offset) // 12
        em = (sm - 1 + offset) % 12 + 1

        return {
            "paid":        paid,
            "remaining":   remaining,
            "total":       total,
            "is_active":   is_active,
            "end_year":    ey,
            "end_month":   em,
            "progress_pct": round(paid / total * 100) if total else 100,
            "amount_due":  float(emi["amount"]) if is_active else 0.0,
            "type":        "emi"
        }
    else:
        # Fixed / Recurring Expense
        is_active = (ref.year > sy) or (ref.year == sy and ref.month >= sm)
        # For amount_due, we check if it hits this specific month
        due_this_month = is_emi_active_in_month(emi, ref.year, ref.month)
        
        return {
            "paid":        0,
            "remaining":   0,
            "total":       0,
            "is_active":   is_active,
            "end_year":    None,
            "end_month":   None,
            "progress_pct": 0,
            "amount_due":  float(emi["amount"]) if due_this_month else 0.0,
            "type":        "fixed",
            "frequency":   emi.get("frequency", "monthly"),
            "day_of_month": emi.get("day_of_month", 1)
        }


def is_emi_active_in_month(emi, year, month):
    """Check if an EMI or Fixed Expense has a payment due in the given year/month."""
    sy, sm = int(emi["start_year"]), int(emi["start_month"])
    
    # month index relative to start (0 = first payment month)
    idx = (year - sy) * 12 + (month - sm)
    
    if idx < 0:
        return False
        
    emi_type = emi.get("type", "emi")
    
    if emi_type == "emi":
        total = int(emi.get("total_months", 0))
        return 0 <= idx < total
    else:
        # Fixed / Recurring Expense
        freq = emi.get("frequency", "monthly")
        if freq == "monthly":
            return True
        elif freq == "quarterly":
            return idx % 3 == 0
        elif freq == "every_4_months":
            return idx % 4 == 0
        elif freq == "half_yearly":
            return idx % 6 == 0
        elif freq == "yearly":
            return idx % 12 == 0
        return False


def get_month_extra_income(extra_income_list, year, month):
    """Sum extra income entries that apply to the given calendar month.
    Handles both one-time (date match) and recurring (frequency) entries.
    """
    total = 0.0
    for ei in extra_income_list:
        try:
            ei_type = ei.get("type", "one-time")
            if ei_type == "recurring":
                start = date.fromisoformat(ei.get("start_date", ""))
                # Not started yet?
                if (year, month) < (start.year, start.month):
                    continue
                # Already ended?
                end_s = ei.get("end_date", "").strip()
                if end_s:
                    end_d = date.fromisoformat(end_s)
                    if (year, month) > (end_d.year, end_d.month):
                        continue
                # Check frequency
                months_since = (year - start.year) * 12 + (month - start.month)
                freq = ei.get("frequency", "monthly")
                if freq == "monthly":
                    applies = True
                elif freq == "quarterly":
                    applies = months_since % 3 == 0
                elif freq == "half_yearly":
                    applies = months_since % 6 == 0
                elif freq == "yearly":
                    applies = months_since % 12 == 0
                else:
                    applies = True
                if applies:
                    total += float(ei["amount"])
            else:
                # one-time: original behaviour
                d = date.fromisoformat(ei["date"])
                if d.year == year and d.month == month:
                    total += float(ei["amount"])
        except Exception:
            pass
    return total


def get_billing_period_for_n_ago(n, bsd, ref_today=None):
    """Get the billing period that is n periods ago (0 = current).

    Returns (start, end) dates for billing period n cycles back.
    """
    ref = ref_today or date.today()
    day = min(bsd, 28)

    # Get current billing start
    curr_start, curr_end = get_billing_period(bsd)

    if n == 0:
        return curr_start, curr_end

    month = curr_start.month - n
    year  = curr_start.year
    while month <= 0:
        month += 12
        year  -= 1

    start = date(year, month, min(day, monthrange(year, month)[1]))

    # end = one day before start + 1 billing month
    next_m = month + 1
    next_y = year
    if next_m > 12:
        next_m = 1
        next_y += 1
    end = date(next_y, next_m, min(day, monthrange(next_y, next_m)[1])) - timedelta(days=1)

    return start, end


def format_inr(amount):
    """Format number with currency. Uses Indian grouping for INR, Western for others."""
    try:
        from flask import g, has_request_context
        if has_request_context():
            symbol = getattr(g, 'currency_symbol', '₹')
            code   = getattr(g, 'currency_code', 'INR')
        else:
            symbol, code = '₹', 'INR'
        n = int(round(float(amount)))
        s = str(abs(n))
        sign = "-" if n < 0 else ""
        if code == "INR":
            if len(s) <= 3:
                return f"{sign}{symbol}{s}"
            last3 = s[-3:]
            rest  = s[:-3]
            groups = []
            while len(rest) > 2:
                groups.insert(0, rest[-2:])
                rest = rest[:-2]
            if rest:
                groups.insert(0, rest)
            return f"{sign}{symbol}" + ",".join(groups) + "," + last3
        else:
            formatted = f"{abs(n):,}"
            return f"{sign}{symbol}{formatted}"
    except Exception:
        return f"{amount}"

# Make helpers available in templates
app.jinja_env.globals["get_category_color"] = lambda c: CATEGORY_COLORS.get(c, "#9CA3AF")
app.jinja_env.globals["format_inr"] = format_inr
app.jinja_env.globals["today_str"] = today_str
app.jinja_env.globals["billing_period_label"] = billing_period_label

# ── Currency & Cloud Configuration ────────────────────────────────────────────

@app.before_request
def load_currency_to_g():
    try:
        data = load_data()
        code = data.get("currency_code", "INR")
        cur = next((c for c in CURRENCIES if c["code"] == code), CURRENCIES[0])
        from flask import g
        g.currency_symbol = cur["symbol"]
        g.currency_code = code
    except Exception:
        from flask import g
        g.currency_symbol = "₹"
        g.currency_code = "INR"


@app.context_processor
def inject_currency():
    from flask import g
    return {
        "currency_symbol": getattr(g, 'currency_symbol', '₹'),
        "currency_code":   getattr(g, 'currency_code', 'INR'),
        "currencies":      CURRENCIES,
    }


CLOUD_TOKENS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cloud_tokens.json")

# ── Developer OAuth credentials (fill these in once after registering your apps) ──
# Google Drive:  console.cloud.google.com  → OAuth 2.0 → Desktop app
# OneDrive:      portal.azure.com          → App registrations → Mobile/Desktop
# Dropbox:       dropbox.com/developers    → Create app
# Redirect URI for all three: http://localhost:5000/cloud/callback/<service>
CLOUD_CREDENTIALS = {
    "gdrive": {
        "client_id":     "YOUR_GOOGLE_CLIENT_ID",
        "client_secret": "YOUR_GOOGLE_CLIENT_SECRET",
    },
    "onedrive": {
        "client_id": "YOUR_MICROSOFT_CLIENT_ID",
    },
    "dropbox": {
        "app_key":    "YOUR_DROPBOX_APP_KEY",
        "app_secret": "YOUR_DROPBOX_APP_SECRET",
    },
}

def load_cloud_tokens():
    if not os.path.exists(CLOUD_TOKENS_FILE):
        return {}
    with open(CLOUD_TOKENS_FILE) as f:
        return json.load(f)

def save_cloud_tokens(tokens):
    with open(CLOUD_TOKENS_FILE, "w") as f:
        json.dump(tokens, f, indent=2)

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    data = load_data()
    expenses = data["expenses"]
    bsd = int(data.get("billing_start_day", 1))

    today = today_str()
    bill_start, bill_end = get_billing_period(bsd)
    bill_start_s = bill_start.isoformat()
    bill_end_s   = bill_end.isoformat()

    today_expenses   = [e for e in expenses if e["date"] == today]
    billing_expenses = [e for e in expenses
                        if bill_start_s <= e["date"] <= bill_end_s]

    today_total   = sum(e["amount"] for e in today_expenses)
    billing_total = sum(e["amount"] for e in billing_expenses)

    # Category totals for billing period
    cat_totals = defaultdict(float)
    for e in billing_expenses:
        cat_totals[e["category"]] += e["amount"]
    top_categories = sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)[:5]

    # Payment method totals for billing period
    pm_totals = defaultdict(float)
    for e in billing_expenses:
        pm_totals[e["payment_method"]] += e["amount"]

    # Recent 10 transactions
    recent = sorted(expenses,
                    key=lambda x: (x["date"], x.get("created_at", "")),
                    reverse=True)[:10]

    # Days elapsed & remaining in billing period
    today_dt      = date.today()
    days_elapsed  = max((today_dt - bill_start).days + 1, 1)
    days_total    = (bill_end - bill_start).days + 1
    days_left     = max((bill_end - today_dt).days, 0)
    daily_avg     = billing_total / days_elapsed
    projected     = daily_avg * days_total

    return render_template(
        "dashboard.html",
        today_total=today_total,
        billing_total=billing_total,
        projected=projected,
        daily_avg=daily_avg,
        days_left=days_left,
        days_elapsed=days_elapsed,
        days_total=days_total,
        today_expenses=today_expenses,
        recent=recent,
        top_categories=top_categories,
        pm_totals=dict(pm_totals),
        templates=data["templates"][:8],
        billing_label=billing_period_label(bsd),
        billing_start=bill_start_s,
        billing_end=bill_end_s,
        billing_start_day=bsd,
        today=today,
    )


@app.route("/add", methods=["GET", "POST"])
def add_expense():
    data = load_data()
    categories = get_all_categories(data)

    if request.method == "POST":
        # Validate amount
        try:
            amount = float(request.form.get("amount", "").strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            flash("Please enter a valid positive amount.", "danger")
            return redirect(url_for("add_expense"))

        category    = request.form.get("category", "").strip()
        subcategory = request.form.get("subcategory", "").strip()
        new_sub     = request.form.get("new_subcategory", "").strip()

        if new_sub:
            subcategory = new_sub
            cc = data.setdefault("custom_categories", {})
            cc.setdefault(category, [])
            if new_sub not in cc[category]:
                cc[category].append(new_sub)

        expense = {
            "id":             str(uuid.uuid4()),
            "amount":         round(amount, 2),
            "category":       category,
            "subcategory":    subcategory,
            "date":           request.form.get("date", today_str()),
            "payment_method": request.form.get("payment_method", "Cash"),
            "notes":          request.form.get("notes", "").strip(),
            "created_at":     datetime.now().isoformat(),
        }
        data["expenses"].append(expense)

        # Optionally save as template
        if request.form.get("save_as_template"):
            tname = request.form.get("template_name", subcategory).strip() or subcategory
            data["templates"].append({
                "id":             str(uuid.uuid4()),
                "name":           tname,
                "category":       category,
                "subcategory":    subcategory,
                "amount":         round(amount, 2),
                "payment_method": expense["payment_method"],
            })

        save_data(data)
        from flask import g
        flash(f"✓ {g.currency_symbol}{amount:.0f} added — {subcategory} ({category})", "success")

        # Redirect based on button clicked
        if request.form.get("add_another"):
            return redirect(url_for("add_expense"))
        return redirect(url_for("dashboard"))

    return render_template(
        "add_expense.html",
        categories=categories,
        payment_methods=data["payment_methods"],
        today=today_str(),
        category_colors=CATEGORY_COLORS,
    )


@app.route("/add-from-template/<template_id>")
def add_from_template(template_id):
    data = load_data()
    tmpl = next((t for t in data["templates"] if t["id"] == template_id), None)
    if not tmpl:
        flash("Template not found.", "danger")
        return redirect(url_for("dashboard"))

    expense = {
        "id":             str(uuid.uuid4()),
        "amount":         tmpl["amount"],
        "category":       tmpl["category"],
        "subcategory":    tmpl["subcategory"],
        "date":           today_str(),
        "payment_method": tmpl["payment_method"],
        "notes":          f"Quick add: {tmpl['name']}",
        "created_at":     datetime.now().isoformat(),
    }
    data["expenses"].append(expense)
    save_data(data)
    flash(f"✓ {tmpl['name']} — ₹{tmpl['amount']:.0f} added!", "success")
    return redirect(url_for("dashboard"))


@app.route("/expenses")
def view_expenses():
    data = load_data()
    expenses = data["expenses"]
    categories = get_all_categories(data)

    date_from  = request.args.get("date_from", "")
    date_to    = request.args.get("date_to", "")
    category   = request.args.get("category", "")
    payment    = request.args.get("payment", "")
    search     = request.args.get("search", "").lower()
    
    # Pagination parameters
    try:
        page = int(request.args.get("page", 1))
        per_page = request.args.get("per_page", "50")
    except (ValueError, TypeError):
        page = 1
        per_page = "50"

    filtered = expenses
    if date_from:
        filtered = [e for e in filtered if e["date"] >= date_from]
    if date_to:
        filtered = [e for e in filtered if e["date"] <= date_to]
    if category:
        filtered = [e for e in filtered if e["category"] == category]
    if payment:
        filtered = [e for e in filtered if e["payment_method"] == payment]
    if search:
        filtered = [e for e in filtered if
                    search in e.get("notes", "").lower() or
                    search in e["category"].lower() or
                    search in e["subcategory"].lower()]

    filtered = sorted(filtered,
                      key=lambda x: (x["date"], x.get("created_at", "")),
                      reverse=True)
    total_count = len(filtered)
    total_amount = sum(e["amount"] for e in filtered)

    # Determine numeric per_page value
    if per_page == "all":
        per_page_val = total_count if total_count > 0 else 50
    else:
        try:
            per_page_val = int(per_page)
        except ValueError:
            per_page_val = 50

    # Apply pagination
    start_idx = (page - 1) * per_page_val
    end_idx = start_idx + per_page_val
    paginated_expenses = filtered[start_idx:end_idx]
    
    total_pages = (total_count + per_page_val - 1) // per_page_val if per_page_val > 0 else 1

    # Total of CURRENTLY VISIBLE items on this page
    page_total = sum(e["amount"] for e in paginated_expenses)

    # Calculate Current Billing Cycle Total
    bsd = int(data.get("billing_start_day", 1))
    bill_start, bill_end = get_billing_period(bsd)
    bs_s, be_s = bill_start.isoformat(), bill_end.isoformat()
    
    billing_cycle_expenses = [e for e in expenses if bs_s <= e["date"] <= be_s]
    billing_cycle_total = sum(e["amount"] for e in billing_cycle_expenses)

    return render_template(
        "view_expenses.html",
        expenses=paginated_expenses,
        total=page_total,
        filtered_total=total_amount,
        billing_cycle_total=billing_cycle_total,
        billing_label=billing_period_label(bsd),
        total_count=total_count,
        categories=list(categories.keys()),
        payment_methods=data["payment_methods"],
        filters={"date_from": date_from, "date_to": date_to,
                 "category": category, "payment": payment, "search": search,
                 "page": page, "per_page": per_page},
        total_pages=total_pages,
        current_page=page
    )


@app.route("/delete/<expense_id>", methods=["POST"])
def delete_expense(expense_id):
    data = load_data()
    data["expenses"] = [e for e in data["expenses"] if e["id"] != expense_id]
    save_data(data)
    flash("Expense deleted.", "info")
    return redirect(request.referrer or url_for("view_expenses"))


@app.route("/edit/<expense_id>", methods=["GET", "POST"])
def edit_expense(expense_id):
    data = load_data()
    expense = next((e for e in data["expenses"] if e["id"] == expense_id), None)
    if not expense:
        flash("Expense not found.", "danger")
        return redirect(url_for("view_expenses"))

    categories = get_all_categories(data)

    if request.method == "POST":
        try:
            amount = float(request.form.get("amount", "").strip())
            if amount <= 0: raise ValueError
        except ValueError:
            flash("Please enter a valid positive amount.", "danger")
            return redirect(url_for("edit_expense", expense_id=expense_id))

        category    = request.form.get("category", "").strip()
        subcategory = request.form.get("subcategory", "").strip()
        new_sub     = request.form.get("new_subcategory", "").strip()

        if new_sub:
            subcategory = new_sub
            cc = data.setdefault("custom_categories", {})
            cc.setdefault(category, [])
            if new_sub not in cc[category]:
                cc[category].append(new_sub)

        # Update expense
        expense["amount"]         = round(amount, 2)
        expense["category"]       = category
        expense["subcategory"]    = subcategory
        expense["date"]           = request.form.get("date", today_str())
        expense["payment_method"] = request.form.get("payment_method", "Cash")
        expense["notes"]          = request.form.get("notes", "").strip()

        save_data(data)
        flash(f"✓ Expense updated successfully.", "success")
        return redirect(url_for("view_expenses"))

    return render_template(
        "edit_expense.html",
        expense=expense,
        categories=categories,
        payment_methods=data["payment_methods"],
        category_colors=CATEGORY_COLORS,
    )


@app.route("/analytics")
def analytics():
    data = load_data()
    # Build list of available months from expense data
    months = sorted(set(e["date"][:7] for e in data["expenses"]), reverse=True)
    if not months:
        months = [date.today().strftime("%Y-%m")]
    return render_template("analytics.html",
                           months=months,
                           current_month=date.today().strftime("%Y-%m"))


@app.route("/templates")
def manage_templates():
    data = load_data()
    categories = get_all_categories(data)
    return render_template(
        "manage_templates.html",
        templates=data["templates"],
        categories=categories,
        payment_methods=data["payment_methods"],
    )


@app.route("/templates/add", methods=["POST"])
def add_template():
    data = load_data()
    try:
        amount = float(request.form.get("amount", 0))
    except ValueError:
        amount = 0.0
    template = {
        "id":             str(uuid.uuid4()),
        "name":           request.form.get("name", "").strip(),
        "category":       request.form.get("category", "").strip(),
        "subcategory":    request.form.get("subcategory", "").strip(),
        "amount":         round(amount, 2),
        "payment_method": request.form.get("payment_method", "Cash"),
    }
    data["templates"].append(template)
    save_data(data)
    flash(f"Template '{template['name']}' saved!", "success")
    return redirect(url_for("manage_templates"))


@app.route("/templates/delete/<template_id>", methods=["POST"])
def delete_template(template_id):
    data = load_data()
    data["templates"] = [t for t in data["templates"] if t["id"] != template_id]
    save_data(data)
    flash("Template deleted.", "info")
    return redirect(url_for("manage_templates"))


@app.route("/settings", methods=["GET", "POST"])
def settings():
    data = load_data()
    if request.method == "POST":
        # Handle Payment Methods
        originals = request.form.getlist("pm_original")
        currents = request.form.getlist("pm_current")
        
        # 1. Handle Renames (where both old and new values exist and differ)
        for old_name, new_name in zip(originals, currents):
            old_name = old_name.strip()
            new_name = new_name.strip()
            if old_name and new_name and old_name != new_name:
                # Update expenses
                for e in data["expenses"]:
                    if e["payment_method"] == old_name:
                        e["payment_method"] = new_name
                # Update templates
                for t in data["templates"]:
                    if t["payment_method"] == old_name:
                        t["payment_method"] = new_name
                # Update fixed expenses (EMIs)
                for f in data["fixed_expenses"]:
                    if f.get("payment_method") == old_name:
                        f["payment_method"] = new_name

        # 2. Update the master list (filtering out empty values)
        new_pms = [p.strip() for p in currents if p.strip()]
        if not new_pms:
            new_pms = DEFAULT_PAYMENT_METHODS
        data["payment_methods"] = new_pms

        # Handle Billing Start Day
        try:
            bsd = int(request.form.get("billing_start_day", 1))
            bsd = max(1, min(28, bsd))
        except (ValueError, TypeError):
            bsd = 1
        data["billing_start_day"] = bsd

        # Handle Currency
        currency_code = request.form.get("currency_code", "INR")
        valid_codes = [c["code"] for c in CURRENCIES]
        if currency_code in valid_codes:
            data["currency_code"] = currency_code

        save_data(data)
        flash("Settings saved and data updated!", "success")
        return redirect(url_for("settings"))

    bsd = int(data.get("billing_start_day", 1))
    preview_start, preview_end = get_billing_period(bsd)
    tokens = load_cloud_tokens()
    cloud_connected = {
        "gdrive":   "gdrive" in tokens,
        "onedrive": "onedrive" in tokens,
        "dropbox":  "dropbox" in tokens,
    }
    return render_template("settings.html",
                           payment_methods=data["payment_methods"],
                           billing_start_day=bsd,
                           billing_preview=f"{preview_start.strftime('%b %d')} – {preview_end.strftime('%b %d, %Y')}",
                           currency_code=data.get("currency_code", "INR"),
                           cloud_connected=cloud_connected)


# ── API endpoints for charts ──────────────────────────────────────────────────

@app.route("/api/init-data")
def api_init_data():
    data = load_data()
    return jsonify({
        "categories": list(get_all_categories(data).keys()),
        "payment_methods": data.get("payment_methods", DEFAULT_PAYMENT_METHODS)
    })


@app.route("/api/subcategories/<category>")
def api_subcategories(category):
    data = load_data()
    cats = get_all_categories(data)
    return jsonify(cats.get(category, []))


@app.route("/api/analytics/monthly")
def api_monthly():
    data = load_data()
    month_str = request.args.get("month", date.today().strftime("%Y-%m"))
    year, mon = map(int, month_str.split("-"))
    num_days = monthrange(year, mon)[1]
    start_s = f"{month_str}-01"
    end_s   = f"{month_str}-{num_days:02d}"

    expenses = [e for e in data["expenses"] if e["date"].startswith(month_str)]

    cat_totals = defaultdict(float)
    for e in expenses:
        cat_totals[e["category"]] += e["amount"]

    # Include active EMIs for this month
    for emi in data.get("fixed_expenses", []):
        if is_emi_active_in_month(emi, year, mon):
            cat_totals[emi.get("category", "EMI / Finance")] += float(emi["amount"])

    # Sort categories by amount descending
    sorted_cats = sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)
    labels  = [item[0] for item in sorted_cats]
    amounts = [round(item[1], 2) for item in sorted_cats]
    colors  = [CATEGORY_COLORS.get(l, "#9CA3AF") for l in labels]
    total   = sum(amounts)

    return jsonify({"labels": labels, "amounts": amounts,
                    "colors": colors, "total": total,
                    "start": start_s, "end": end_s})


@app.route("/api/analytics/daily")
def api_daily():
    data  = load_data()
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    expenses = [e for e in data["expenses"] if e["date"].startswith(month)]

    daily = defaultdict(float)
    for e in expenses:
        daily[e["date"]] += e["amount"]

    year, mon = map(int, month.split("-"))
    num_days = monthrange(year, mon)[1]
    day_labels = [f"{month}-{d:02d}" for d in range(1, num_days + 1)]
    amounts    = [round(daily.get(l, 0), 2) for l in day_labels]
    display    = [str(d) for d in range(1, num_days + 1)]

    return jsonify({"labels": display, "amounts": amounts})


@app.route("/api/analytics/radar")
def api_radar():
    """Data for radar chart: Category (axes) vs Payment Method (series)."""
    data = load_data()
    month_str = request.args.get("month", date.today().strftime("%Y-%m"))
    year, mon = map(int, month_str.split("-"))
    
    expenses = [e for e in data["expenses"] if e["date"].startswith(month_str)]
    
    # Get all unique categories and payment methods that have data
    categories = sorted(list(set(e["category"] for e in expenses)))
    payment_methods = sorted(list(set(e["payment_method"] for e in expenses)))
    
    # Also check fixed expenses (EMIs) for this month
    fixed_this_month = [f for f in data.get("fixed_expenses", []) if is_emi_active_in_month(f, year, mon)]
    if fixed_this_month:
        for f in fixed_this_month:
            cat = f.get("category", "EMI / Finance")
            if cat not in categories:
                categories.append(cat)
        if "EMI" not in payment_methods:
            payment_methods.append("EMI")
        categories.sort()
        payment_methods.sort()

    # Build the matrix: payment_method -> { category -> total }
    matrix = {pm: {cat: 0.0 for cat in categories} for pm in payment_methods}
    
    for e in expenses:
        matrix[e["payment_method"]][e["category"]] += e["amount"]
        
    for f in fixed_this_month:
        matrix["EMI"][f.get("category", "EMI / Finance")] += float(f["amount"])
        
    # Format for Chart.js radar
    datasets = []
    for pm in payment_methods:
        datasets.append({
            "label": pm,
            "data": [round(matrix[pm][cat], 2) for cat in categories]
        })
        
    return jsonify({
        "labels": categories,
        "datasets": datasets
    })


@app.route("/api/analytics/payment-methods")
def api_payment_methods():
    data  = load_data()
    month_str = request.args.get("month", date.today().strftime("%Y-%m"))
    year, mon = map(int, month_str.split("-"))
    num_days = monthrange(year, mon)[1]
    start_s = f"{month_str}-01"
    end_s   = f"{month_str}-{num_days:02d}"

    expenses = [e for e in data["expenses"] if e["date"].startswith(month_str)]

    pm = defaultdict(float)
    for e in expenses:
        pm[e["payment_method"]] += e["amount"]

    # Include active EMIs for this month — always in their own "EMI" bucket
    for emi in data.get("fixed_expenses", []):
        if is_emi_active_in_month(emi, year, mon):
            pm["EMI"] += float(emi["amount"])

    # Sort by amount descending
    sorted_pm = sorted(pm.items(), key=lambda x: x[1], reverse=True)
    return jsonify({"labels":  [r[0] for r in sorted_pm],
                    "amounts": [round(r[1], 2) for r in sorted_pm],
                    "start":   start_s, "end": end_s})


@app.route("/api/analytics/comparison")
def api_comparison():
    data  = load_data()
    today = date.today()
    curr_month = today.strftime("%Y-%m")
    prev_month = (today.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")

    def cat_totals(month):
        t = defaultdict(float)
        for e in data["expenses"]:
            if e["date"].startswith(month):
                t[e["category"]] += e["amount"]
        return t

    curr = cat_totals(curr_month)
    prev = cat_totals(prev_month)
    all_cats = sorted(set(list(curr.keys()) + list(prev.keys())))

    return jsonify({
        "categories":    all_cats,
        "current":       [round(curr.get(c, 0), 2) for c in all_cats],
        "previous":      [round(prev.get(c, 0), 2) for c in all_cats],
        "current_label": today.strftime("%B"),
        "previous_label": (today.replace(day=1) - timedelta(days=1)).strftime("%B"),
        "colors":        [CATEGORY_COLORS.get(c, "#9CA3AF") for c in all_cats],
    })


@app.route("/api/analytics/subcategory")
def api_subcategory():
    """Frequency data — how many times each subcategory was bought this month."""
    data  = load_data()
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    expenses = [e for e in data["expenses"] if e["date"].startswith(month)]

    freq   = defaultdict(int)
    totals = defaultdict(float)
    for e in expenses:
        key = f"{e['category']} › {e['subcategory']}"
        freq[key]   += 1
        totals[key] += e["amount"]

    rows = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:15]
    return jsonify({
        "labels":  [r[0] for r in rows],
        "counts":  [freq[r[0]] for r in rows],
        "amounts": [round(totals[r[0]], 2) for r in rows],
    })


@app.route("/api/period-stats")
def api_period_stats():
    """Flexible period analytics for dashboard filter.

    ?period=billing|3months|6months|12months|year|custom
    ?from=YYYY-MM-DD  (only for period=custom)
    ?to=YYYY-MM-DD    (only for period=custom)

    All multi-month periods are aligned to billing month boundaries.
    'year' is the only calendar-based option (Jan 1 – today).
    """
    data   = load_data()
    period = request.args.get("period", "billing")
    today  = date.today()
    bsd    = int(data.get("billing_start_day", 1))

    if period in ("billing", "month"):        # "month" kept for back-compat
        ps, pe = get_billing_period(bsd)
    elif period in ("3months", "quarter"):    # "quarter" kept for back-compat
        ps, pe = get_n_billing_months_ago(3, bsd)
    elif period in ("6months", "half"):       # "half" kept for back-compat
        ps, pe = get_n_billing_months_ago(6, bsd)
    elif period == "12months":
        ps, pe = get_n_billing_months_ago(12, bsd)
    elif period == "year":
        ps = today.replace(month=1, day=1)
        pe = today
    elif period == "custom":
        try:
            ps = date.fromisoformat(request.args.get("from", today.isoformat()))
            pe = date.fromisoformat(request.args.get("to",   today.isoformat()))
        except ValueError:
            ps = pe = today
    else:
        ps, pe = get_billing_period(bsd)

    ps_s, pe_s = ps.isoformat(), pe.isoformat()
    expenses = [e for e in data["expenses"] if ps_s <= e["date"] <= pe_s]

    cat_totals = defaultdict(float)
    pm_totals  = defaultdict(float)
    daily      = defaultdict(float)
    for e in expenses:
        cat_totals[e["category"]] += e["amount"]
        pm_totals[e["payment_method"]] += e["amount"]
        daily[e["date"]] += e["amount"]

    # Include active EMIs — iterate by BILLING month boundaries (bsd-anchored)
    # so that a single billing period (e.g. Feb 21–Mar 20) counts each EMI
    # exactly once, not twice just because it crosses a calendar-month boundary.
    bsd_day = min(int(data.get("billing_start_day", 1)), 28)
    billing_curr = ps  # ps is already a billing-month start date
    while billing_curr <= pe:
        for emi in data.get("fixed_expenses", []):
            if is_emi_active_in_month(emi, billing_curr.year, billing_curr.month):
                cat_totals[emi.get("category", "EMI / Finance")] += float(emi["amount"])
                pm_totals["EMI"] += float(emi["amount"])  # EMIs are always shown as their own payment bucket
        # Advance to next billing-month start
        next_m = billing_curr.month + 1
        next_y = billing_curr.year
        if next_m > 12:
            next_m = 1
            next_y += 1
        next_day = min(bsd_day, monthrange(next_y, next_m)[1])
        billing_curr = date(next_y, next_m, next_day)

    total = sum(cat_totals.values())
    days_span = max((pe - ps).days + 1, 1)

    # Category list sorted by amount desc
    cat_labels  = sorted(cat_totals, key=cat_totals.get, reverse=True)
    cat_amounts = [round(cat_totals[c], 2) for c in cat_labels]
    cat_colors  = [CATEGORY_COLORS.get(c, "#9CA3AF") for c in cat_labels]
    cat_pct     = [round(cat_totals[c] / total * 100, 1) if total else 0 for c in cat_labels]

    # Daily amounts for the period
    day_labels, day_amounts = [], []
    d = ps
    while d <= pe:
        day_labels.append(d.strftime("%d %b"))
        day_amounts.append(round(daily.get(d.isoformat(), 0), 2))
        d += timedelta(days=1)

    # Label for the period
    def _period_range_label(start, end):
        if start.month == end.month and start.year == end.year:
            return f"{start.strftime('%b')} {start.day} – {end.day}, {end.year}"
        if start.year == end.year:
            return f"{start.strftime('%b')} {start.day} – {end.strftime('%b')} {end.day}, {end.year}"
        return f"{start.strftime('%b %d, %Y')} – {end.strftime('%b %d, %Y')}"

    if period in ("billing", "month"):
        label = billing_period_label(bsd)
    elif period in ("3months", "quarter"):
        label = f"3 Months  ({_period_range_label(ps, pe)})"
    elif period in ("6months", "half"):
        label = f"6 Months  ({_period_range_label(ps, pe)})"
    elif period == "12months":
        label = f"12 Months  ({_period_range_label(ps, pe)})"
    elif period == "year":
        label = f"Calendar Year {today.year}  (Jan 1 – {today.strftime('%b %d')})"
    else:
        label = f"{ps_s} to {pe_s}"

    return jsonify({
        "label":       label,
        "start":       ps_s,
        "end":         pe_s,
        "total":       round(total, 2),
        "count":       len(expenses),
        "daily_avg":   round(total / days_span, 2),
        "cat_labels":  cat_labels,
        "cat_amounts": cat_amounts,
        "cat_colors":  cat_colors,
        "cat_pct":     cat_pct,
        "pm_labels":   list(pm_totals.keys()),
        "pm_amounts":  [round(v, 2) for v in pm_totals.values()],
        "day_labels":  day_labels,
        "day_amounts": day_amounts,
    })


@app.route("/api/transactions-detail")
def api_transactions_detail():
    """Return list of transactions for a specific period, filtered by category or payment method."""
    data = load_data()
    start_s = request.args.get("start")
    end_s   = request.args.get("end")
    category = request.args.get("category")
    payment  = request.args.get("payment")

    if not start_s or not end_s:
        return jsonify({"expenses": [], "emis": []})

    expenses = [e for e in data["expenses"] if start_s <= e["date"] <= end_s]

    if category:
        expenses = [e for e in expenses if e["category"] == category]
    if payment:
        if payment == "EMI":
            # "EMI" is a virtual payment bucket — no regular expenses live here
            expenses = []
        else:
            expenses = [e for e in expenses if e["payment_method"] == payment]

    # Include EMIs — iterate by BILLING month boundaries so a single billing
    # period (e.g. Feb 21–Mar 20) never double-counts an EMI just because the
    # period crosses a calendar-month boundary.
    matching_emis = []
    seen_emis = set()
    try:
        ps = date.fromisoformat(start_s)
        pe = date.fromisoformat(end_s)
        bsd_day = min(int(data.get("billing_start_day", 1)), 28)

        billing_curr = ps  # ps is already a billing-month start
        while billing_curr <= pe:
            month_key = f"{billing_curr.year}-{billing_curr.month:02d}"
            for emi in data.get("fixed_expenses", []):
                emi_id = emi.get("id")
                unique_key = f"{emi_id}_{month_key}"
                if unique_key not in seen_emis and is_emi_active_in_month(emi, billing_curr.year, billing_curr.month):
                    cat_match = not category or emi.get("category") == category
                    # payment=="EMI" → show all EMIs (they're in the virtual EMI bucket)
                    # payment set to something else → hide EMIs (they no longer belong there)
                    # no payment filter → include EMIs (category drill-down)
                    if payment == "EMI":
                        pm_match = True
                    elif payment:
                        pm_match = False
                    else:
                        pm_match = True
                    if cat_match and pm_match:
                        st = get_emi_status(emi, date.today())
                        matching_emis.append({
                            "name":         emi["name"],
                            "amount":       emi["amount"],
                            "month":        month_key,
                            "is_active":    st["is_active"],
                            "paid":         st["paid"],
                            "total":        st["total"],
                            "remaining":    st["remaining"],
                            "progress_pct": st["progress_pct"],
                            "type":         st["type"],
                            "frequency":    st.get("frequency", "monthly"),
                            "day_of_month": st.get("day_of_month", 1),
                        })
                        seen_emis.add(unique_key)
            # Advance to next billing-month start
            next_m = billing_curr.month + 1
            next_y = billing_curr.year
            if next_m > 12:
                next_m = 1
                next_y += 1
            next_day = min(bsd_day, monthrange(next_y, next_m)[1])
            billing_curr = date(next_y, next_m, next_day)
    except Exception:
        pass

    return jsonify({
        "expenses": sorted(expenses, key=lambda x: x["date"], reverse=True),
        "emis": matching_emis
    })


@app.route("/api/billing-preview")
def api_billing_preview():
    """Live preview of a billing period for the settings page."""
    try:
        day = int(request.args.get("day", 1))
        day = max(1, min(28, day))
    except (ValueError, TypeError):
        day = 1
    start, end = get_billing_period(day)
    return jsonify({
        "preview": f"{start.strftime('%b %d')} – {end.strftime('%b %d, %Y')}",
        "start":   start.isoformat(),
        "end":     end.isoformat(),
    })


@app.route("/api/billing-period")
def api_billing_period():
    """Returns analytics data for the current billing period."""
    data = load_data()
    bsd  = int(data.get("billing_start_day", 1))
    bill_start, bill_end = get_billing_period(bsd)
    bs, be = bill_start.isoformat(), bill_end.isoformat()

    expenses = [e for e in data["expenses"] if bs <= e["date"] <= be]

    cat_totals = defaultdict(float)
    pm_totals  = defaultdict(float)
    daily      = defaultdict(float)
    for e in expenses:
        cat_totals[e["category"]] += e["amount"]
        pm_totals[e["payment_method"]] += e["amount"]
        daily[e["date"]] += e["amount"]

    # Include active EMIs for this billing period month
    # We use the start of the billing period to decide which EMI month to count
    for emi in data.get("fixed_expenses", []):
        if is_emi_active_in_month(emi, bill_start.year, bill_start.month):
            cat_totals[emi.get("category", "EMI / Finance")] += float(emi["amount"])
            pm_totals[emi.get("payment_method", "Cash")] += float(emi["amount"])

    # Daily breakdown across the billing period
    from datetime import timedelta
    day_labels, day_amounts = [], []
    d = bill_start
    while d <= bill_end:
        day_labels.append(d.strftime("%d %b"))
        day_amounts.append(round(daily.get(d.isoformat(), 0), 2))
        d += timedelta(days=1)

    labels  = list(cat_totals.keys())
    amounts = [round(cat_totals[l], 2) for l in labels]

    return jsonify({
        "label":       billing_period_label(bsd),
        "start":       bs,
        "end":         be,
        "total":       round(sum(amounts), 2),
        "cat_labels":  labels,
        "cat_amounts": amounts,
        "cat_colors":  [CATEGORY_COLORS.get(l, "#9CA3AF") for l in labels],
        "pm_labels":   list(pm_totals.keys()),
        "pm_amounts":  [round(v, 2) for v in pm_totals.values()],
        "day_labels":  day_labels,
        "day_amounts": day_amounts,
    })


# ── Income & Budget routes ────────────────────────────────────────────────────

@app.route("/income", methods=["GET", "POST"])
def income():
    data = load_data()

    if request.method == "POST":
        action = request.form.get("action", "")

        if action == "set_salary":
            try:
                sal = float(request.form.get("salary", "0").replace(",", "").strip())
                sal = max(0.0, sal)
            except ValueError:
                sal = 0.0
            effective_from = request.form.get("effective_from", "").strip()
            if not effective_from:
                effective_from = date.today().isoformat()
            # Append to history (no overwrite — old entries stay locked)
            history = data["income"].setdefault("salary_history", [])
            history.append({
                "amount":         round(sal, 2),
                "effective_from": effective_from,
                "added_on":       date.today().isoformat(),
            })
            history.sort(key=lambda h: h["effective_from"])
            # Keep flat field in sync with the currently effective salary
            current_sal = get_salary_for_date(data["income"], date.today())
            data["income"]["monthly_salary"] = current_sal
            data["income"]["salary_updated"] = effective_from
            save_data(data)
            flash("Salary saved. Historical entries remain unchanged.", "success")

        elif action == "add_extra":
            try:
                amt = float(request.form.get("amount", "0").replace(",", "").strip())
                if amt <= 0:
                    raise ValueError
            except ValueError:
                flash("Please enter a valid amount.", "danger")
                return redirect(url_for("income"))

            ei_type = request.form.get("ei_type", "one-time")
            entry = {
                "id":          str(uuid.uuid4()),
                "amount":      round(amt, 2),
                "description": request.form.get("description", "").strip() or "Extra Income",
                "type":        ei_type,
            }
            if ei_type == "recurring":
                entry["start_date"] = request.form.get("start_date", date.today().isoformat())
                entry["end_date"]   = request.form.get("end_date", "").strip()
                entry["frequency"]  = request.form.get("frequency", "monthly")
                # Keep a dummy date for backward-compat display
                entry["date"]       = entry["start_date"]
            else:
                entry["date"] = request.form.get("date", date.today().isoformat())

            data["extra_income"].append(entry)
            save_data(data)
            freq_label = {"monthly": "monthly", "quarterly": "quarterly",
                          "half_yearly": "every 6 months", "yearly": "yearly"}.get(
                          entry.get("frequency", ""), "")
            msg = f"Recurring income added ({freq_label})." if ei_type == "recurring" else "Extra income added."
            flash(msg, "success")

        elif action == "add_emi":
            try:
                amt = float(request.form.get("amount", "0").replace(",", "").strip())
                emi_type = request.form.get("type", "emi")
                start_year   = int(request.form.get("start_year", date.today().year))
                start_month  = int(request.form.get("start_month", date.today().month))
                
                category = request.form.get("category", "").strip()
                new_cat  = request.form.get("new_category", "").strip()
                if category == "__new__" and new_cat:
                    category = new_cat
                    cc = data.setdefault("custom_categories", {})
                    if category not in cc:
                        cc[category] = [] # Initialize with empty subcategory list

                if emi_type == "emi":
                    total_months = int(request.form.get("total_months", "0"))
                    if amt <= 0 or total_months <= 0:
                        raise ValueError
                    frequency = "monthly"
                    day_of_month = 1
                else:
                    total_months = 0
                    frequency = request.form.get("frequency", "monthly")
                    day_of_month = int(request.form.get("day_of_month", "1"))
                    if amt <= 0:
                        raise ValueError
            except (ValueError, TypeError):
                flash("Please fill in all fields correctly.", "danger")
                return redirect(url_for("income"))
            
            emi = {
                "id":           str(uuid.uuid4()),
                "name":         request.form.get("name", "").strip() or "Expense",
                "amount":       round(amt, 2),
                "type":         emi_type,
                "frequency":    frequency,
                "day_of_month": day_of_month,
                "start_year":   start_year,
                "start_month":  start_month,
                "total_months": total_months,
                "category":     category or "EMI / Finance",
                "payment_method": request.form.get("payment_method", "Cash"),
            }
            data["fixed_expenses"].append(emi)
            save_data(data)
            flash(f"{'EMI' if emi_type == 'emi' else 'Fixed Expense'} '{emi['name']}' added.", "success")

        return redirect(url_for("income"))

    # GET — build context
    today = date.today()
    salary = get_salary_for_date(data["income"], today)
    bsd    = int(data.get("billing_start_day", 1))
    bill_start, bill_end = get_billing_period(bsd)

    # Extra income this billing cycle
    extra_this_cycle = sum(
        float(ei["amount"])
        for ei in data["extra_income"]
        if bill_start.isoformat() <= ei.get("date", "") <= bill_end.isoformat()
    )

    # Enrich EMIs with status
    emis = []
    for emi in data["fixed_expenses"]:
        st = get_emi_status(emi, today)
        emis.append({**emi, "status": st})

    # Sort EMIs: Active first, then Fixed Expenses on top, then EMIs by end date
    def emi_sort_key(x):
        st = x["status"]
        is_active = st["is_active"]
        # etype: 0 for fixed (top), 1 for emi
        etype = 0 if st.get("type") == "fixed" else 1
        
        if st.get("type") == "fixed":
            # Sort fixed by start date (oldest first)
            sy = int(x.get("start_year", 0))
            sm = int(x.get("start_month", 0))
            return (not is_active, etype, sy, sm)
        else:
            # Sort EMIs by end date (earliest closing first)
            end_year = st["end_year"] if st["end_year"] is not None else 9999
            end_month = st["end_month"] if st["end_month"] is not None else 12
            return (not is_active, etype, end_year, end_month)

    emis.sort(key=emi_sort_key)

    active_emi_total = sum(
        float(e["amount"]) for e in data["fixed_expenses"]
        if is_emi_active_in_month(e, today.year, today.month)
    )

    # Recent extra income (last 20)
    extra_sorted = sorted(data["extra_income"], key=lambda x: x.get("date", ""), reverse=True)[:20]

    categories = list(get_all_categories(data).keys())
    pm_list    = data.get("payment_methods", DEFAULT_PAYMENT_METHODS)

    salary_history = sorted(
        data["income"].get("salary_history", []),
        key=lambda h: h["effective_from"],
        reverse=True,
    )

    return render_template(
        "income.html",
        salary=salary,
        salary_updated=data["income"].get("salary_updated", ""),
        salary_history=salary_history,
        extra_income=extra_sorted,
        all_extra_income=data["extra_income"],
        extra_this_cycle=extra_this_cycle,
        emis=emis,
        active_emi_total=active_emi_total,
        billing_label=billing_period_label(bsd),
        today=today.isoformat(),
        today_year=today.year,
        today_month=today.month,
        categories=categories,
        pm_list=pm_list,
    )


@app.route("/income/extra/delete/<eid>", methods=["POST"])
def delete_extra_income(eid):
    data = load_data()
    data["extra_income"] = [e for e in data["extra_income"] if e["id"] != eid]
    save_data(data)
    flash("Extra income entry deleted.", "success")
    return redirect(url_for("income"))


@app.route("/income/emi/delete/<eid>", methods=["POST"])
def delete_emi(eid):
    data = load_data()
    data["fixed_expenses"] = [e for e in data["fixed_expenses"] if e["id"] != eid]
    save_data(data)
    flash("EMI deleted.", "success")
    return redirect(url_for("income"))


@app.route("/income/emi/edit/<eid>", methods=["GET", "POST"])
def edit_emi(eid):
    data = load_data()
    emi = next((e for e in data["fixed_expenses"] if e["id"] == eid), None)
    if not emi:
        flash("EMI not found.", "danger")
        return redirect(url_for("income"))

    if request.method == "POST":
        try:
            amt = float(request.form.get("amount", "0").replace(",", "").strip())
            emi_type = request.form.get("type", "emi")
            start_year   = int(request.form.get("start_year", date.today().year))
            start_month  = int(request.form.get("start_month", date.today().month))

            category = request.form.get("category", "").strip()
            new_cat  = request.form.get("new_category", "").strip()
            if category == "__new__" and new_cat:
                category = new_cat
                cc = data.setdefault("custom_categories", {})
                if category not in cc:
                    cc[category] = [] # Initialize with empty subcategory list

            if emi_type == "emi":
                total_months = int(request.form.get("total_months", "0"))
                if amt <= 0 or total_months <= 0:
                    raise ValueError
                frequency = "monthly"
                day_of_month = 1
            else:
                total_months = 0
                frequency = request.form.get("frequency", "monthly")
                day_of_month = int(request.form.get("day_of_month", "1"))
                if amt <= 0:
                    raise ValueError

            # Update EMI
            emi["name"]         = request.form.get("name", "").strip() or "Expense"
            emi["amount"]       = round(amt, 2)
            emi["type"]         = emi_type
            emi["frequency"]    = frequency
            emi["day_of_month"] = day_of_month
            emi["start_year"]   = start_year
            emi["start_month"]  = start_month
            emi["total_months"] = total_months
            emi["category"]     = category or "EMI / Finance"
            emi["payment_method"] = request.form.get("payment_method", "Cash")

            save_data(data)
            flash(f"{'EMI' if emi_type == 'emi' else 'Fixed Expense'} '{emi['name']}' updated.", "success")
            return redirect(url_for("income"))

        except (ValueError, TypeError):
            flash("Please fill in all fields correctly.", "danger")
            return redirect(url_for("edit_emi", eid=eid))

    categories = list(get_all_categories(data).keys())
    pm_list    = data.get("payment_methods", DEFAULT_PAYMENT_METHODS)
    return render_template(
        "edit_emi.html",
        emi=emi,
        categories=categories,
        pm_list=pm_list,
    )


@app.route("/api/budget-summary")
def api_budget_summary():
    """Budget + savings summary for dashboard.

    Returns current period budget stats and a 12-month savings trend.
    """
    data  = load_data()
    today = date.today()
    bsd   = int(data.get("billing_start_day", 1))

    salary = get_salary_for_date(data["income"], date.today())
    bill_start, bill_end = get_billing_period(bsd)

    # Extra income this billing cycle
    extra_this_cycle = sum(
        float(ei["amount"])
        for ei in data["extra_income"]
        if bill_start.isoformat() <= ei.get("date", "") <= bill_end.isoformat()
    )
    total_income = salary + extra_this_cycle

    # Active EMIs this billing month (calendar month of bill_start)
    active_emis = [
        e for e in data["fixed_expenses"]
        if is_emi_active_in_month(e, today.year, today.month)
    ]
    emi_total = sum(float(e["amount"]) for e in active_emis)

    # Variable spending in current billing period
    bs_s, be_s = bill_start.isoformat(), bill_end.isoformat()
    billing_spent = sum(
        e["amount"] for e in data["expenses"]
        if bs_s <= e["date"] <= be_s
    )

    available   = max(total_income - emi_total, 0)   # recommended discretionary budget
    remaining   = available - billing_spent            # how much left to spend
    net_savings = total_income - emi_total - billing_spent

    # ── 12-month savings trend ─────────────────────────────────────────────────
    trend_labels, trend_income, trend_fixed, trend_spent, trend_net = [], [], [], [], []

    for n in range(11, -1, -1):     # 11 months ago → current (12 points)
        ps, pe = get_billing_period_for_n_ago(n, bsd, today)
        ps_s, pe_s_t = ps.isoformat(), pe.isoformat()

        period_salary = get_salary_for_date(data["income"], ps)  # salary effective at start of this period

        period_extra = sum(
            float(ei["amount"])
            for ei in data["extra_income"]
            if ps_s <= ei.get("date", "") <= pe_s_t
        )
        period_income = period_salary + period_extra

        # Fixed EMIs active in the STARTING month of that billing period
        period_emi = sum(
            float(e["amount"])
            for e in data["fixed_expenses"]
            if is_emi_active_in_month(e, ps.year, ps.month)
        )

        period_spent = sum(
            e["amount"] for e in data["expenses"]
            if ps_s <= e["date"] <= pe_s_t
        )

        period_net = period_income - period_emi - period_spent

        # Label: "Feb 21" style (start of billing period)
        lbl = f"{ps.strftime('%b')} '{str(ps.year)[2:]}"
        trend_labels.append(lbl)
        trend_income.append(round(period_income, 2))
        trend_fixed.append(round(period_emi, 2))
        trend_spent.append(round(period_spent, 2))
        trend_net.append(round(period_net, 2))

    # ── Future EMI closure projection (next 12 months) ───────────────────────
    future_labels, future_savings = [], []
    for i in range(12):
        fm = today.month + i
        fy = today.year + (fm - 1) // 12
        fm = (fm - 1) % 12 + 1

        fut_emi = sum(
            float(e["amount"])
            for e in data["fixed_expenses"]
            if is_emi_active_in_month(e, fy, fm)
        )
        fut_net = get_salary_for_date(data["income"], date(fy, fm, 1)) or salary  # use future salary if set, else current
        fut_net = fut_net - fut_emi

        lbl = date(fy, fm, 1).strftime("%b '%y")
        future_labels.append(lbl)
        future_savings.append(round(fut_net, 2))

    return jsonify({
        "salary":           round(salary, 2),
        "extra_income":     round(extra_this_cycle, 2),
        "total_income":     round(total_income, 2),
        "emi_total":        round(emi_total, 2),
        "billing_spent":    round(billing_spent, 2),
        "available":        round(available, 2),
        "remaining":        round(remaining, 2),
        "net_savings":      round(net_savings, 2),
        "billing_label":    billing_period_label(bsd),
        "has_salary":       salary > 0,
        "trend_labels":     trend_labels,
        "trend_income":     trend_income,
        "trend_fixed":      trend_fixed,
        "trend_spent":      trend_spent,
        "trend_net":        trend_net,
        "future_labels":    future_labels,
        "future_savings":   future_savings,
    })


# ── Cloud Backup ──────────────────────────────────────────────────────────────

REDIRECT_BASE = "http://localhost:5000"


@app.route("/cloud/connect/<service>")
def cloud_connect(service):
    tokens = load_cloud_tokens()
    state  = secrets.token_urlsafe(16)
    tokens[f"{service}_state"] = state
    save_cloud_tokens(tokens)

    if service == "gdrive":
        params = {
            "client_id":     CLOUD_CREDENTIALS["gdrive"]["client_id"],
            "redirect_uri":  f"{REDIRECT_BASE}/cloud/callback/gdrive",
            "response_type": "code",
            "scope":         "https://www.googleapis.com/auth/drive.file",
            "access_type":   "offline",
            "prompt":        "consent",
            "state":         state,
        }
        return redirect("https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(params))

    elif service == "onedrive":
        params = {
            "client_id":     CLOUD_CREDENTIALS["onedrive"]["client_id"],
            "redirect_uri":  f"{REDIRECT_BASE}/cloud/callback/onedrive",
            "response_type": "code",
            "scope":         "Files.ReadWrite offline_access",
            "state":         state,
        }
        return redirect("https://login.microsoftonline.com/common/oauth2/v2.0/authorize?" + urllib.parse.urlencode(params))

    elif service == "dropbox":
        params = {
            "client_id":         CLOUD_CREDENTIALS["dropbox"]["app_key"],
            "redirect_uri":      f"{REDIRECT_BASE}/cloud/callback/dropbox",
            "response_type":     "code",
            "token_access_type": "offline",
            "state":             state,
        }
        return redirect("https://www.dropbox.com/oauth2/authorize?" + urllib.parse.urlencode(params))

    flash("Unknown service.", "danger")
    return redirect(url_for("settings"))


@app.route("/cloud/callback/<service>")
def cloud_callback(service):
    code  = request.args.get("code")
    state = request.args.get("state")
    error = request.args.get("error")

    if error:
        flash(f"Authorization denied: {error}", "danger")
        return redirect(url_for("settings") + "#cloud-backup")

    tokens = load_cloud_tokens()
    saved_state = tokens.get(f"{service}_state", "")
    if state != saved_state:
        flash("Invalid state — possible CSRF. Please try again.", "danger")
        return redirect(url_for("settings") + "#cloud-backup")

    try:
        if service == "gdrive":
            cid     = CLOUD_CREDENTIALS["gdrive"]["client_id"]
            csecret = CLOUD_CREDENTIALS["gdrive"]["client_secret"]
            post_data = urllib.parse.urlencode({
                "code":          code,
                "client_id":     cid,
                "client_secret": csecret,
                "redirect_uri":  f"{REDIRECT_BASE}/cloud/callback/gdrive",
                "grant_type":    "authorization_code",
            }).encode()
            req = urllib.request.Request("https://oauth2.googleapis.com/token",
                                          data=post_data, method="POST")
            with urllib.request.urlopen(req) as r:
                tk = json.loads(r.read())
            tokens["gdrive"] = tk
            tokens["gdrive_file_id"] = tokens.get("gdrive_file_id", "")

        elif service == "onedrive":
            post_data = urllib.parse.urlencode({
                "code":          code,
                "client_id":     CLOUD_CREDENTIALS["onedrive"]["client_id"],
                "redirect_uri":  f"{REDIRECT_BASE}/cloud/callback/onedrive",
                "grant_type":    "authorization_code",
                "scope":         "Files.ReadWrite offline_access",
            }).encode()
            req = urllib.request.Request(
                "https://login.microsoftonline.com/common/oauth2/v2.0/token",
                data=post_data, method="POST")
            with urllib.request.urlopen(req) as r:
                tk = json.loads(r.read())
            tokens["onedrive"] = tk

        elif service == "dropbox":
            key    = CLOUD_CREDENTIALS["dropbox"]["app_key"]
            secret = CLOUD_CREDENTIALS["dropbox"]["app_secret"]
            post_data = urllib.parse.urlencode({
                "code":          code,
                "grant_type":    "authorization_code",
                "redirect_uri":  f"{REDIRECT_BASE}/cloud/callback/dropbox",
            }).encode()
            import base64
            auth = base64.b64encode(f"{key}:{secret}".encode()).decode()
            req = urllib.request.Request(
                "https://api.dropboxapi.com/oauth2/token",
                data=post_data, method="POST",
                headers={"Authorization": f"Basic {auth}"})
            with urllib.request.urlopen(req) as r:
                tk = json.loads(r.read())
            tokens["dropbox"] = tk

        save_cloud_tokens(tokens)
        svc_names = {"gdrive": "Google Drive", "onedrive": "OneDrive", "dropbox": "Dropbox"}
        flash(f"✓ Connected to {svc_names.get(service, service)} successfully!", "success")

    except Exception as e:
        flash(f"Connection failed: {e}", "danger")

    return redirect(url_for("settings") + "#cloud-backup")


@app.route("/cloud/backup/<service>", methods=["POST"])
def cloud_backup(service):
    tokens = load_cloud_tokens()
    svc_token = tokens.get(service)
    if not svc_token:
        flash(f"Not connected to {service}. Connect first.", "danger")
        return redirect(url_for("settings") + "#cloud-backup")

    try:
        with open(DATA_FILE, "rb") as f:
            file_bytes = f.read()

        if service == "gdrive":
            access_token = svc_token.get("access_token", "")
            file_id = tokens.get("gdrive_file_id", "")

            if file_id:
                # Update existing file
                req = urllib.request.Request(
                    f"https://www.googleapis.com/upload/drive/v3/files/{file_id}?uploadType=media",
                    data=file_bytes, method="PATCH",
                    headers={"Authorization": f"Bearer {access_token}",
                             "Content-Type": "application/json"})
            else:
                # Create new file
                import json as _json
                meta = _json.dumps({"name": "spendsight_backup.json",
                                     "mimeType": "application/json"}).encode()
                boundary = b"boundary_spendsight"
                body = (b"--" + boundary + b"\r\n"
                        b"Content-Type: application/json; charset=UTF-8\r\n\r\n" +
                        meta + b"\r\n"
                        b"--" + boundary + b"\r\n"
                        b"Content-Type: application/json\r\n\r\n" +
                        file_bytes + b"\r\n"
                        b"--" + boundary + b"--")
                req = urllib.request.Request(
                    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
                    data=body, method="POST",
                    headers={"Authorization": f"Bearer {access_token}",
                             "Content-Type": f"multipart/related; boundary={boundary.decode()}"})
            with urllib.request.urlopen(req) as r:
                resp = json.loads(r.read())
            if not file_id:
                tokens["gdrive_file_id"] = resp.get("id", "")
                save_cloud_tokens(tokens)

        elif service == "onedrive":
            access_token = svc_token.get("access_token", "")
            req = urllib.request.Request(
                "https://graph.microsoft.com/v1.0/me/drive/root:/spendsight_backup.json:/content",
                data=file_bytes, method="PUT",
                headers={"Authorization": f"Bearer {access_token}",
                         "Content-Type": "application/json"})
            with urllib.request.urlopen(req) as r:
                r.read()

        elif service == "dropbox":
            access_token = svc_token.get("access_token", "")
            import json as _json
            arg = _json.dumps({"path": "/spendsight_backup.json", "mode": "overwrite"})
            req = urllib.request.Request(
                "https://content.dropboxapi.com/2/files/upload",
                data=file_bytes, method="POST",
                headers={"Authorization": f"Bearer {access_token}",
                         "Content-Type": "application/octet-stream",
                         "Dropbox-API-Arg": arg})
            with urllib.request.urlopen(req) as r:
                r.read()

        svc_names = {"gdrive": "Google Drive", "onedrive": "OneDrive", "dropbox": "Dropbox"}
        flash(f"✓ Backed up to {svc_names.get(service, service)} successfully!", "success")

    except Exception as e:
        flash(f"Backup failed: {e}", "danger")

    return redirect(url_for("settings") + "#cloud-backup")


@app.route("/cloud/restore/<service>", methods=["POST"])
def cloud_restore(service):
    tokens = load_cloud_tokens()
    svc_token = tokens.get(service)
    if not svc_token:
        flash(f"Not connected to {service}.", "danger")
        return redirect(url_for("settings") + "#cloud-backup")

    try:
        access_token = svc_token.get("access_token", "")

        if service == "gdrive":
            file_id = tokens.get("gdrive_file_id", "")
            if not file_id:
                flash("No backup file found on Google Drive.", "warning")
                return redirect(url_for("settings") + "#cloud-backup")
            req = urllib.request.Request(
                f"https://www.googleapis.com/drive/v3/files/{file_id}?alt=media",
                headers={"Authorization": f"Bearer {access_token}"})
            with urllib.request.urlopen(req) as r:
                content = r.read()

        elif service == "onedrive":
            req = urllib.request.Request(
                "https://graph.microsoft.com/v1.0/me/drive/root:/spendsight_backup.json:/content",
                headers={"Authorization": f"Bearer {access_token}"})
            with urllib.request.urlopen(req) as r:
                content = r.read()

        elif service == "dropbox":
            import json as _json
            arg = _json.dumps({"path": "/spendsight_backup.json"})
            req = urllib.request.Request(
                "https://content.dropboxapi.com/2/files/download",
                method="POST",
                headers={"Authorization": f"Bearer {access_token}",
                         "Dropbox-API-Arg": arg,
                         "Content-Type": ""})
            with urllib.request.urlopen(req) as r:
                content = r.read()

        # Validate JSON before overwriting
        json.loads(content)
        with open(DATA_FILE, "wb") as f:
            f.write(content)

        svc_names = {"gdrive": "Google Drive", "onedrive": "OneDrive", "dropbox": "Dropbox"}
        flash(f"✓ Restored from {svc_names.get(service, service)} successfully!", "success")

    except Exception as e:
        flash(f"Restore failed: {e}", "danger")

    return redirect(url_for("settings") + "#cloud-backup")


@app.route("/cloud/disconnect/<service>", methods=["POST"])
def cloud_disconnect(service):
    tokens = load_cloud_tokens()
    tokens.pop(service, None)
    if service == "gdrive":
        tokens.pop("gdrive_file_id", None)
    save_cloud_tokens(tokens)
    svc_names = {"gdrive": "Google Drive", "onedrive": "OneDrive", "dropbox": "Dropbox"}
    flash(f"Disconnected from {svc_names.get(service, service)}.", "info")
    return redirect(url_for("settings") + "#cloud-backup")


@app.route("/api/cloud/status")
def api_cloud_status():
    tokens = load_cloud_tokens()
    return jsonify({
        "gdrive":   "gdrive" in tokens,
        "onedrive": "onedrive" in tokens,
        "dropbox":  "dropbox" in tokens,
    })


# ── Spending Forecast ─────────────────────────────────────────────────────────

@app.route("/api/spending-forecast")
def api_spending_forecast():
    data     = load_data()
    today_dt = date.today()
    bsd      = int(data.get("billing_start_day", 1))
    day      = min(bsd, 28)

    salary = get_salary_for_date(data["income"], today_dt)
    if salary <= 0:
        return jsonify({"has_salary": False})

    # ── Average monthly variable spending over last 3 billing cycles ──
    past_totals = []
    cur_start, cur_end = get_billing_period(bsd)
    ref = cur_start
    for _ in range(3):
        # Step back one billing month
        m = ref.month - 1 or 12
        y = ref.year if ref.month > 1 else ref.year - 1
        max_d = monthrange(y, m)[1]
        p_start = date(y, m, min(day, max_d))
        p_end   = ref - timedelta(days=1)
        total   = sum(
            e["amount"] for e in data["expenses"]
            if p_start.isoformat() <= e["date"] <= p_end.isoformat()
        )
        past_totals.append(total)
        ref = p_start

    avg_spend = round(sum(past_totals) / len(past_totals), 2) if past_totals else 0

    # ── Build next 3 billing periods ──
    months = []
    ref_start = cur_start
    for i in range(3):
        # Advance one billing month
        m = ref_start.month % 12 + 1
        y = ref_start.year + (1 if ref_start.month == 12 else 0)
        max_d   = monthrange(y, m)[1]
        f_start = date(y, m, min(day, max_d))
        m2 = f_start.month % 12 + 1
        y2 = f_start.year + (1 if f_start.month == 12 else 0)
        max_d2 = monthrange(y2, m2)[1]
        f_end   = date(y2, m2, min(day, max_d2)) - timedelta(days=1)

        # EMIs active this month
        emi_total = sum(
            float(emi["amount"]) for emi in data.get("fixed_expenses", [])
            if is_emi_active_in_month(emi, f_start.year, f_start.month)
        )

        # Extra income for this month (one-time entries)
        extra = get_month_extra_income(data.get("extra_income", []), f_start.year, f_start.month)

        total_income  = round(salary + extra, 2)
        available     = round(total_income - emi_total, 2)
        projected_bal = round(available - avg_spend, 2)

        months.append({
            "label":         f_start.strftime("%B %Y"),
            "period":        f"{f_start.strftime('%b %d')} – {f_end.strftime('%b %d')}",
            "salary":        round(salary, 2),
            "extra_income":  round(extra, 2),
            "total_income":  total_income,
            "emi_total":     round(emi_total, 2),
            "available":     available,
            "avg_spend":     avg_spend,
            "projected_bal": projected_bal,
            "status":        "safe" if projected_bal >= 0 else "risk",
        })
        ref_start = f_start

    return jsonify({
        "has_salary": True,
        "avg_spend":  avg_spend,
        "months":     months,
    })


# ── Export ────────────────────────────────────────────────────────────────────

@app.route("/export/csv")
def export_csv():
    from flask import Response, g
    data = load_data()
    expenses = sorted(data["expenses"], key=lambda x: x["date"], reverse=True)
    symbol = getattr(g, 'currency_symbol', '₹')

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Date", "Category", "Subcategory", f"Amount ({symbol})", "Payment Method", "Note"])
    for e in expenses:
        writer.writerow([
            e.get("date", ""),
            e.get("category", ""),
            e.get("subcategory", ""),
            e.get("amount", 0),
            e.get("payment_method", ""),
            e.get("note", ""),
        ])

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=spendsight_expenses.csv"}
    )


@app.route("/export/pdf")
def export_pdf():
    from flask import Response, g
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import cm
    except ImportError:
        flash("PDF export requires reportlab. Run: pip install reportlab", "danger")
        return redirect(url_for("view_expenses"))

    data   = load_data()
    symbol = getattr(g, 'currency_symbol', '₹')
    expenses = sorted(data["expenses"], key=lambda x: x["date"], reverse=True)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=1.5*cm, rightMargin=1.5*cm,
                            topMargin=1.5*cm, bottomMargin=1.5*cm)
    styles = getSampleStyleSheet()
    elements = []

    # Title
    title = Paragraph("<b>SpendSight — Expense Report</b>", styles["Title"])
    elements.append(title)
    elements.append(Spacer(1, 0.4*cm))
    sub = Paragraph(f"Generated: {date.today().strftime('%B %d, %Y')}  ·  Total records: {len(expenses)}", styles["Normal"])
    elements.append(sub)
    elements.append(Spacer(1, 0.6*cm))

    # Table
    header = ["Date", "Category", "Subcategory", f"Amount ({symbol})", "Payment", "Note"]
    rows = [header]
    for e in expenses:
        rows.append([
            e.get("date", ""),
            e.get("category", ""),
            e.get("subcategory", ""),
            f"{symbol}{e.get('amount', 0):.0f}",
            e.get("payment_method", ""),
            (e.get("note", "") or "")[:40],
        ])

    col_widths = [2.2*cm, 3*cm, 3*cm, 2.5*cm, 2.8*cm, None]
    t = Table(rows, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND",  (0,0), (-1,0), colors.HexColor("#1A56DB")),
        ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
        ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",    (0,0), (-1,-1), 8),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f1f5f9")]),
        ("GRID",        (0,0), (-1,-1), 0.4, colors.HexColor("#e2e8f0")),
        ("VALIGN",      (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 5),
        ("RIGHTPADDING",(0,0), (-1,-1), 5),
        ("TOPPADDING",  (0,0), (-1,-1), 4),
        ("BOTTOMPADDING",(0,0), (-1,-1), 4),
    ]))
    elements.append(t)

    doc.build(elements)
    buf.seek(0)
    return Response(
        buf.getvalue(),
        mimetype="application/pdf",
        headers={"Content-Disposition": "attachment; filename=spendsight_expenses.pdf"}
    )


# ── Launch ────────────────────────────────────────────────────────────────────

def open_browser():
    webbrowser.open("http://localhost:5000")

if __name__ == "__main__":
    print("\n" + "="*50)
    print("  SpendSight is starting...")
    print("  Open: http://localhost:5000")
    print("  Press Ctrl+C to stop")
    print("="*50 + "\n")
    threading.Timer(1.2, open_browser).start()
    app.run(debug=False, port=5000, use_reloader=False)
